import pickle
import pandas as pd
import xgboost as xgb
import streamlit as st
import numpy as np



# Load the trained model using load function in pickle 
loaded_model=pickle.load(open('C:/Users/nerella/Downloads/Desktop/ML CAPSTONE/training_model.sav','rb'))

laptop_data_path='C:/Users/nerella/Downloads/Desktop/ML CAPSTONE/laptop_data.csv'
laptop_data=pd.read_csv(laptop_data_path)

x=laptop_data.drop(columns=['Price'])

company_dict=x['Company'].value_counts().to_dict()
x['Company']=x['Company'].map(company_dict)
Type_dict=x['TypeName'].value_counts().to_dict()
x['TypeName']=x['TypeName'].map(Type_dict)
op_dict=x['OpSys'].value_counts().to_dict()
x['OpSys']=x['OpSys'].map(op_dict)
cpu_dict=x['Cpu_Type'].value_counts().to_dict()
x['Cpu_Type']=x['Cpu_Type'].map(cpu_dict)
gpu_dict=x['Gpu Type'].value_counts().to_dict()
x['Gpu Type']=x['Gpu Type'].map(gpu_dict)


def predict_price(input_data):
# Sample single record data
    sample_record = {
        'Company': input_data[0],
        'TypeName': input_data[1],
        'Ram (GB)': input_data[2],
        'OpSys': input_data[3],
        'Weight (KG)': input_data[4],
        'TouchScreen': input_data[5],  # Assuming 1 for Yes and 0 for No
        'IPS': input_data[6],          # Assuming 1 for Yes and 0 for No
        'HD': input_data[7],           # Assuming 1 for Yes and 0 for No
        'X_Resolution': input_data[8],
        'Y_Resolution': input_data[9],
        'Cpu_Type': input_data[10],
        'SSD': input_data[11],
        'Gpu Type': input_data[12],
        'HDD':input_data[13]
    }


    # Map categorical variables based on the encoding dictionaries
    company_encoded = company_dict.get(sample_record['Company'], 0)  # Use 0 if not found in encoding mapping
    type_encoded = Type_dict.get(sample_record['TypeName'], 0)        # Use 0 if not found in encoding mapping
    op_sys_encoded = op_dict.get(sample_record['OpSys'], 0)            # Use 0 if not found in encoding mapping
    cpu_type_encoded = cpu_dict.get(sample_record['Cpu_Type'], 0)      # Use 0 if not found in encoding mapping
    gpu_type_encoded = gpu_dict.get(sample_record['Gpu Type'], 0)    # Use 0 if not found in encoding mapping



    # # Create a DataFrame for the single record
    preprocessed_record = pd.DataFrame({
        'Company': [company_encoded],
        'TypeName': [type_encoded],
        'Ram (GB)': [sample_record['Ram (GB)']],
        'OpSys': [op_sys_encoded],
        'Weight (KG)': [sample_record['Weight (KG)']],
        'TouchScreen': [sample_record['TouchScreen']],
        'IPS': [sample_record['IPS']],
        'HD': [sample_record['HD']],
        'X_Resolution': [sample_record['X_Resolution']],
        'Y_Resolution': [sample_record['Y_Resolution']],
        'Cpu_Type': [cpu_type_encoded],
        'HDD':[sample_record['HDD']],
        'SSD': [sample_record['SSD']],
        'Gpu Type': [gpu_type_encoded],

    })



    # Converting every column to numerical
    preprocessed_record=preprocessed_record.apply(pd.to_numeric,errors='coerce')

    df=pd.DataFrame()

    for col in preprocessed_record.columns:
        mean_col=x[col].mean()
        std_col=x[col].std()
        standard_value=(preprocessed_record[col]-mean_col)/std_col
        df[col]=standard_value
    



  

    #Make predictions using the preprocessed record and your trained XGBoost model
    prediction = loaded_model.predict(df)
    return prediction[0]
    
def convert_to_binary(input_value):
    if(input_value=='Yes'):
        return 1
    elif(input_value=='No'):
        return 0

def main():
    # Giving a title
    st.title('Laptop Price Prediction')

    # Giving the input data from the user
    company=st.selectbox('Company',laptop_data['Company'].unique())
    typename=st.selectbox('Type Name',laptop_data['TypeName'].unique())
    ram=st.text_input('Ram (GB)')
    opsys=st.selectbox('Operating Sysytem',laptop_data['OpSys'].unique())
    weight=st.text_input('Weight (KG)')
    touchscreen=st.selectbox('Touch Screen',['No','Yes'])
    ips=st.selectbox('IPS',['No','Yes'])
    hd=st.selectbox('HD',['No','Yes'])
    x_res=st.text_input('X Resolution')
    y_res=st.text_input('Y Resolution')
    cpu=st.selectbox('CPU',laptop_data['Cpu_Type'].unique())
    hdd=st.selectbox('HDD',laptop_data['HDD'].unique())
    ssd=st.selectbox('SSD',laptop_data['SSD'].unique())
    gpu=st.selectbox('GPU',laptop_data['Gpu Type'].unique())

    

    if weight.strip():  # Check if the string is not empty
        try:
            weight = float(weight.strip())
        except ValueError:
            st.error('Invalid input. Please enter a numeric value for weight.')

    if x_res.strip():  # Check if the string is not empty
        try:
            x_res = int(x_res.strip())
        except ValueError:
            st.error('Invalid input. Please enter a numeric value for X Resolution.')
  
    if y_res.strip():  # Check if the string is not empty
        try:
            y_res= int(y_res.strip())
        except ValueError:
            st.error('Invalid input. Please enter a numeric value for Y Resolution.')
    
    
    if ram.strip():  # Check if the string is not empty
        try:
            ram = int(ram.strip())
        except ValueError:
            st.error('Invalid input. Please enter a numeric value for ram')



 
   
    # Creating a button for prediction

    if st.button('Predict'):
        touchscreen_binary = 1 if touchscreen == 'Yes' else 0 if touchscreen == 'No' else None
        ips_binary = 1 if ips == 'Yes' else 0 if ips == 'No' else None
        hd_binary = 1 if hd == 'Yes' else 0 if hd == 'No' else None

        try:
        
            # Check if all fields are filled
            if all([company, typename, ram, opsys, weight, touchscreen_binary, ips_binary, hd_binary, x_res, y_res, cpu, hdd, ssd, gpu]) or hdd==0 or ssd==0:
                columns=np.array([company, typename, ram, opsys, weight, touchscreen_binary, ips_binary, hd_binary, x_res, y_res, cpu, hdd, ssd, gpu])
                prediction_price = predict_price(columns)
                st.success(prediction_price)
            else:
            # Identify which fields are missing
                missing_fields = []
                if not company:
                       missing_fields.append("Company")
                if not typename:
                    missing_fields.append("Type Name")
                if not ram:
                    missing_fields.append("RAM (GB)")
                if not opsys:
                    missing_fields.append("opsys)")
                if not weight:
                    missing_fields.append("wt")
                if not touchscreen:
                    missing_fields.append("tb")
                if not hd:
                    missing_fields.append("hb")
                if not ips:
                    missing_fields.append("ib")
                if not x_res:
                    missing_fields.append("x")
                if not y_res:
                    missing_fields.append("y")
                if not cpu:
                    missing_fields.append("cpu")
                if not hdd:
                    missing_fields.append("hdd")
                if not ssd:
                    missing_fields.append("ssd")
                if not gpu:
                    missing_fields.append("gpu")
                  
                error_message = f'Please fill the following fields: {", ".join(missing_fields)}'
                st.error(error_message)
        except Exception as e:
            st.error(f"Error during prediction: {e}")

        except ValueError:
            st.error('Invalid input. Please ensure weight, X resolution, and Y resolution are numeric values.')
    

    
if __name__=='__main__':
    main()
